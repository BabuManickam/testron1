# Solution — Instructor only

## Required: Days in Hospital column

`src/components/PatientTable.tsx`
```tsx
<th>Days in Hospital</th>   {/* add after Risk */}
...
<td colSpan={5}>No encounters found</td>   {/* 4 → 5 */}
```

`src/components/PatientRow.tsx`
```tsx
<td>{encounter.time_in_hospital}</td>   {/* add after risk_level */}
```

## Stretch: age search in App

```tsx
const [ageSearch, setAgeSearch] = useState('');

const visibleEncounters = encounters.filter((item) =>
  item.age.toLowerCase().includes(ageSearch.trim().toLowerCase())
);
```
```tsx
<label htmlFor="ageSearch">Search by age range</label>
<input
  id="ageSearch"
  value={ageSearch}
  onChange={(event) => setAgeSearch(event.target.value)}
/>
<PatientTable encounters={visibleEncounters} />
```
Filtering is **derived data**: compute it during render. No second `useEffect`.
