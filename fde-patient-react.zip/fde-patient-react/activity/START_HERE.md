# Activity — add one column (10 minutes)

The API already returns `time_in_hospital`, and the `Encounter` type already has it.

**Task:** show hospital days as another column in the table.

Questions first:
1. Which file contains the table heading?
2. Which file contains an individual row?

Check at the end: every row in the browser shows the right number.

---

## Stretch (only if the class is on schedule)

Add a controlled age search **in `App`**.

1. Add state for the search text.
2. Calculate a filtered list from `encounters` directly (derived data — **no second `useEffect`**).
3. Add a labeled input.
4. Pass the filtered list to `PatientTable`.

No POST or forms today.
