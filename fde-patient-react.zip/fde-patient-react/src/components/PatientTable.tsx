import type { Encounter } from '../types';
import PatientRow from './PatientRow';

interface PatientTableProps {
  encounters: Encounter[];
}

export default function PatientTable({ encounters }: PatientTableProps) {
  return (
    <table>
      <thead>
        <tr>
          <th>Encounter ID</th>
          <th>Patient Number</th>
          <th>Age</th>
          <th>Risk</th>
        </tr>
      </thead>
      <tbody>
        {encounters.length === 0 ? (
          <tr>
            <td colSpan={4}>No encounters found</td>
          </tr>
        ) : (
          encounters.map((item) => (
            <PatientRow key={item.encounter_id} encounter={item} />
          ))
        )}
      </tbody>
    </table>
  );
}
