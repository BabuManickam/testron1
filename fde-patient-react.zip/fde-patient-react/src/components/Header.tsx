export default function Header() {
  return (
    <header>
      <h1>Diabetes Patient Management</h1>
      <p>Care Management — Patient Encounters</p>
    </header>
  );
}
