import { useEffect, useState } from 'react';
import Header from './components/Header';
import PatientTable from './components/PatientTable';
import type { Encounter } from './types';
import './App.css';

const API_URL =
  import.meta.env.VITE_API_URL || 'http://localhost:8000';

export default function App() {
  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const controller = new AbortController();

    async function loadEncounters() {
      try {
        const response = await fetch(
          `${API_URL}/encounters?limit=20`,
          { signal: controller.signal }
        );

        if (!response.ok) {
          throw new Error('Unable to load encounters');
        }

        const data: unknown = await response.json();

        if (!Array.isArray(data)) {
          throw new Error('Expected an array of encounters');
        }

        if (!controller.signal.aborted) {
          setEncounters(data as Encounter[]);
        }
      } catch (err) {
        if (!controller.signal.aborted) {
          setError(
            err instanceof Error ? err.message : 'Unexpected error'
          );
        }
      } finally {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    }

    void loadEncounters();
    return () => controller.abort();
  }, []);

  return (
    <main className="container">
      <Header />

      <h2>Patient Encounter List</h2>
      {loading && <p>Loading encounters...</p>}
      {error && <p role="alert">Error: {error}</p>}
      {!loading && !error && (
        <PatientTable encounters={encounters} />
      )}
    </main>
  );
}
