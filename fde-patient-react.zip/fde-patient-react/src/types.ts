export interface Encounter {
  encounter_id: number;
  patient_nbr: number;
  age: string;
  time_in_hospital: number;
  risk_level: string;
}
