# GET contract and CORS (trainer / support)

## Contract (verified from `diabetes-readmission-intervention/app/main.py`, `repository.py`, `sql/01_create_schema.sql`)

`GET http://localhost:8000/encounters?limit=20` returns a **bare JSON array** (`SELECT * FROM patient_encounters ... LIMIT`). Columns used by the frontend:

| Field | Type |
|---|---|
| encounter_id | number |
| patient_nbr | number |
| age | string, e.g. `"[60-70)"` |
| time_in_hospital | number |
| risk_level | `"LOW"` / `"MEDIUM"` / `"HIGH"` |

The rows contain more columns; the frontend ignores them. Limit is 1–500 (default 50).
**Before class, curl the live endpoint** to confirm — this was verified from source only. If the shape differs (e.g. `{items: [...]}`), change slides and frontend consistently.

Saturday is **GET only**. The backend also has `POST /encounters`; do not use it today.

## Checks
1. FastAPI starts. 2. `http://localhost:8000/docs` loads. 3. `/encounters` returns rows. 4. PostgreSQL has data.

## CORS
The existing backend already uses `CORSMiddleware` with `allow_origins=["*"]`, so no change is needed. Do not edit it for class. If you ever lock it down, allow the exact origin and keep existing methods:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["GET"],  # widen if other clients need more
    allow_headers=["*"],
)
```
If Vite picks another port, add the origin it prints. React never talks to PostgreSQL directly.
