# CP3 — Extract Header

## Goal
Move the heading into its own named component.

## Why this step matters
Components let us name and reuse pieces of the page.

## File to edit
Create `src/components/Header.tsx`; edit `src/App.tsx`.

## Code to add/change
`src/components/Header.tsx`
```tsx
export default function Header() {
  return (
    <header>
      <h1>Diabetes Patient Management</h1>
      <p>Care Management — Patient Encounters</p>
    </header>
  );
}
```
`src/App.tsx`
```tsx
import Header from './components/Header';
import './App.css';

export default function App() {
  return (
    <main className="container">
      <Header />
    </main>
  );
}
```

## Command / how to run
`npm run dev`

## Expected browser result
The page looks exactly the same. We only extracted one piece.

## Common error and fix
- Component name starts lowercase (`<header />`) → React treats it as an HTML tag; use `<Header />`.
- Missing `export default` or wrong import path → fix the import.

## STOP checkpoint
Heading and subtitle still display. You can point to `Header.tsx` and `<Header />`.
