# CP8 — `useEffect` with live GET, loading and error

## Goal
Load encounters automatically when the page opens.

## Why this step matters
The API is outside React. `useEffect` is where the component coordinates that external request. Do not teach the full lifecycle, and never write `useEffect(async () => ...)`.

## File to edit
`src/App.tsx` (final version below); `.env.example` is already provided.

## Code to add/change
See [`src/App.tsx`](../src/App.tsx) — the finished Saturday version. Key points:
```tsx
const [encounters, setEncounters] = useState<Encounter[]>([]);
const [loading, setLoading] = useState(true);
const [error, setError] = useState('');

useEffect(() => {
  const controller = new AbortController();
  async function loadEncounters() { /* fetch → setEncounters(data) */ }
  void loadEncounters();
  return () => controller.abort();
}, []);
```
The manual "Load" button and sample data are removed.

Trainer-only: don't dwell on `AbortController` (stops obsolete requests updating state) or `unknown` + `Array.isArray` (turns a wrong response shape into a visible error). In dev, Strict Mode may fire the effect twice — expected.

`VITE_` variables are visible in the browser. Never put secrets there; the backend URL is not a secret.

## Command / how to run
```bash
cp .env.example .env   # optional; default is the same URL
npm run dev
```

## Expected browser result
"Loading encounters..." briefly, then the real table. Refreshing the page works. Stop the backend → "Error: ..." message appears. Empty database → "No encounters found".

## Common error and fix
- Blank page + `map` error → response is not an array.
- CORS error → fix backend origins, not React.
- Changed `.env` but nothing changed → restart `npm run dev`.

## STOP checkpoint
React loads the real encounter table automatically; refresh still works; loading/error/empty states behave.
