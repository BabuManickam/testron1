# CP4 — Data type, PatientRow, and props

## Goal
Pass one typed encounter from `App` to `PatientRow` through props.

## Why this step matters
`PatientRow` does not create data. Its parent gives it data through props.

## File to edit
Create `src/types.ts` and `src/components/PatientRow.tsx`; edit `src/App.tsx`.

## Code to add/change
`src/types.ts`
```ts
export interface Encounter {
  encounter_id: number;
  patient_nbr: number;
  age: string;
  time_in_hospital: number;
  risk_level: string;
}
```
`src/components/PatientRow.tsx`
```tsx
import type { Encounter } from '../types';

interface PatientRowProps {
  encounter: Encounter;
}

export default function PatientRow({ encounter }: PatientRowProps) {
  return (
    <tr>
      <td>{encounter.encounter_id}</td>
      <td>{encounter.patient_nbr}</td>
      <td>{encounter.age}</td>
      <td>{encounter.risk_level}</td>
    </tr>
  );
}
```
`src/App.tsx` (synthetic sample — not real data)
```tsx
import Header from './components/Header';
import PatientRow from './components/PatientRow';
import type { Encounter } from './types';
import './App.css';

const sampleEncounter: Encounter = {
  encounter_id: 1001,
  patient_nbr: 501,
  age: '[60-70)',
  time_in_hospital: 5,
  risk_level: 'MEDIUM',
};

export default function App() {
  return (
    <main className="container">
      <Header />
      <table>
        <tbody>
          <PatientRow encounter={sampleEncounter} />
        </tbody>
      </table>
    </main>
  );
}
```

## Command / how to run
`npm run dev`

## Expected browser result
A table with exactly one row: 1001, 501, [60-70), MEDIUM.

## Common error and fix
- `'Encounter' is a type and must be imported using a type-only import` → use `import type`.
- Row shows nothing → check `encounter={sampleEncounter}` spelling matches the prop name.

## STOP checkpoint
Exactly one sample row appears. You can explain `encounter={sampleEncounter}` and the `encounter` prop.
