# CP2 — First JSX page

## Goal
Replace the template page with our own heading and subtitle.

## Why this step matters
A component is a function that `return`s JSX. JSX looks like HTML but uses `className`. Save → Vite updates the browser.

## File to edit
`src/App.tsx` (and `src/App.css`)

## Code to add/change
```tsx
import './App.css';

export default function App() {
  return (
    <main className="container">
      <h1>Diabetes Patient Management</h1>
      <p>Care Management — Patient Encounters</p>
    </main>
  );
}
```
CSS (`src/App.css`):
```css
body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: #f8fbfa;
  color: #273f52;
}

.container {
  max-width: 980px;
  margin: 32px auto;
  padding: 24px;
}

h1 {
  color: #009763;
}
```

## Command / how to run
`npm run dev` (keep it running; saving refreshes the browser).

## Expected browser result
Green heading "Diabetes Patient Management" with the subtitle underneath.

## Common error and fix
- `class` instead of `className` → use `className`.
- Two sibling elements at the top without a wrapper → wrap in `<main>`.

## STOP checkpoint
Heading and subtitle render. No props, state, or API yet.
