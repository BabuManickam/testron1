# CP9 — Learner activity

## Goal
Independently add `time_in_hospital` as a visible column.

## Why this step matters
Practice reading the component tree: which file owns the heading, which owns a row.

## File to edit
`src/components/PatientTable.tsx` and `src/components/PatientRow.tsx`

## Code to add/change
Prompt only (answer lives in `activity/SOLUTION.md`):
> "The API already returns `time_in_hospital`. Display hospital days as another column. Which file contains the table heading? Which file contains an individual row?"

Optional stretch (only if on schedule): controlled age search in `App`. See `activity/START_HERE.md`.

## Command / how to run
`npm run dev`

## Expected browser result
A new "Days in Hospital" column; every row shows its own value.

## Common error and fix
- Header added but cells misaligned → forgot the `<td>` in `PatientRow`.
- Empty-state row looks short → change `colSpan` to 5.

## STOP checkpoint
Every API row displays its correct hospital-days value.
