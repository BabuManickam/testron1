# CP6 — PatientTable and `map()`

## Goal
Build `PatientTable`, so the flow is App → PatientTable → PatientRow.

## Why this step matters
- `App` owns the array in **state**.
- `PatientTable` receives the array via **props**.
- `PatientRow` receives one item via **props**.
- `.map()` turns each object into a row component.
- `key` is a stable encounter ID, not an array index.

## File to edit
Create `src/components/PatientTable.tsx`; edit `src/App.tsx`.

## Code to add/change
`src/components/PatientTable.tsx`
```tsx
import type { Encounter } from '../types';
import PatientRow from './PatientRow';

interface PatientTableProps {
  encounters: Encounter[];
}

export default function PatientTable({ encounters }: PatientTableProps) {
  return (
    <table>
      <thead>
        <tr>
          <th>Encounter ID</th>
          <th>Patient Number</th>
          <th>Age</th>
          <th>Risk</th>
        </tr>
      </thead>
      <tbody>
        {encounters.length === 0 ? (
          <tr>
            <td colSpan={4}>No encounters found</td>
          </tr>
        ) : (
          encounters.map((item) => (
            <PatientRow key={item.encounter_id} encounter={item} />
          ))
        )}
      </tbody>
    </table>
  );
}
```
In `src/App.tsx`, replace the inline `<table>…</table>` with:
```tsx
<PatientTable encounters={encounters} />
```
and add `import PatientTable from './components/PatientTable';` (remove the now-unused `PatientRow` import).

## Command / how to run
`npm run dev`

## Expected browser result
Table headers always visible. "No encounters found" before click; two sample rows after click.

## Common error and fix
- "Each child in a list should have a unique key" → add `key={item.encounter_id}`.
- `encounters.map is not a function` → the value is not an array.

## STOP checkpoint
App → PatientTable → PatientRow works with two synthetic records. Do not start GET until this works.
