# CP7 — Manual GET with a button

## Goal
Replace sample rows with real rows from FastAPI, triggered by a click.

## Why this step matters
`fetch()` is the same code as last week. The only change: `setEncounters(data)` replaces manual DOM updates.

```text
Last week: fetch → renderPatients(data) → manual DOM updates
Today:     fetch → setEncounters(data)  → React renders rows
```

## File to edit
`src/App.tsx`

## Code to add/change
Inside `App` (it must be inside so it can reach `setEncounters`):
```tsx
const API_URL = 'http://localhost:8000'; // place above the component

async function loadPatients() {
  try {
    const response = await fetch(`${API_URL}/encounters?limit=20`);

    if (!response.ok) {
      throw new Error('Unable to load encounters');
    }

    const data: Encounter[] = await response.json();
    setEncounters(data);
  } catch (error) {
    console.error(error);
  }
}
```
Add the button:
```tsx
<button onClick={loadPatients}>Load Real Encounters</button>
```
The verified backend returns a bare JSON array. If yours returns `{ "items": [...] }`, use `data.items` consistently instead.

## Command / how to run
Terminal 1 (backend): start FastAPI on port 8000. Terminal 2: `npm run dev`.

## Expected browser result
Clicking the button replaces/loads real API records.

## Common error and fix
- `Failed to fetch` / CORS message → backend not running, or Vite origin not allowed (see `backend_notes/GET_CONTRACT_AND_CORS.md`).
- Empty table → check `http://localhost:8000/encounters?limit=20` in the browser.

## STOP checkpoint
Clicking loads actual API records (not the sample data).
