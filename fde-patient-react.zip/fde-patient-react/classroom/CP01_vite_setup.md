# CP1 — Scaffold the React application

## Goal
Create and run a Vite React + TypeScript project.

## Why this step matters
Last week we ran our own `<script>` from HTML. Today Vite starts React, and React displays what our `App` component returns.

## File to edit
None yet. Look at four files only:
- `index.html` → `<div id="root">`
- `src/main.tsx` → starts React
- `src/App.tsx` → our page
- `src/App.css` → its styling

## Code to add/change
None. (Instructor scaffold: `npm create vite@latest fde-patient-react -- --template react-ts`. This repo is already scaffolded.)

## Command / how to run
```bash
node -v
npm -v
npm install
npm run dev
```

## Expected browser result
Open the URL Vite prints (usually http://localhost:5173). The page loads and the terminal shows no errors.

## Common error and fix
- `npm: command not found` → install Node.js LTS.
- Port already in use → Vite picks the next port; use the URL it prints.

## STOP checkpoint
The Vite React page opens; terminal has no errors.
