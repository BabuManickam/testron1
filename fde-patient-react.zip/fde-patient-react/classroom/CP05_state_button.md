# CP5 — State with a button

## Goal
Show rows only after a click, using `useState`.

## Why this step matters
State is data that changes. When `setEncounters` is called, React re-renders.

## File to edit
`src/App.tsx`

## Code to add/change
```tsx
import { useState } from 'react';
import Header from './components/Header';
import PatientRow from './components/PatientRow';
import type { Encounter } from './types';
import './App.css';

// Synthetic sample data for teaching only
const sampleEncounters: Encounter[] = [
  { encounter_id: 1001, patient_nbr: 501, age: '[60-70)', time_in_hospital: 5, risk_level: 'MEDIUM' },
  { encounter_id: 1002, patient_nbr: 502, age: '[70-80)', time_in_hospital: 8, risk_level: 'HIGH' },
];

export default function App() {
  const [encounters, setEncounters] = useState<Encounter[]>([]);

  return (
    <main className="container">
      <Header />
      <button onClick={() => setEncounters(sampleEncounters)}>
        Show Sample Encounters
      </button>
      <table>
        <tbody>
          {encounters.map((item) => (
            <PatientRow key={item.encounter_id} encounter={item} />
          ))}
        </tbody>
      </table>
    </main>
  );
}
```
Explain only the state change now; `map()` is taught formally in CP6.

## Command / how to run
`npm run dev`

## Expected browser result
Before clicking: no rows. After clicking: two rows.

## Common error and fix
- Calling `setEncounters(...)` directly in the render body → infinite loop; call it inside `onClick`.
- `onClick={setEncounters(sampleEncounters)}` → wrap in `() =>`.

## STOP checkpoint
Before click zero rows; after click two rows. No backend data yet.
