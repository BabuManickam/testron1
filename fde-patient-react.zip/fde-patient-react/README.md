# fde-patient-react — Week 4, Day 7

React + TypeScript app that shows existing encounters from `GET /encounters` (read-only).

## 1. Last week vs today
```text
LAST WEEK                    THIS SATURDAY
HTML table                  JSX table
app.js                      React components
createElement + appendChild PatientRow + map()
Manual DOM updates          setEncounters() + React render
fetch('/encounters')        SAME fetch('/encounters')
FastAPI + PostgreSQL        SAME FastAPI + PostgreSQL
```

## 2. What you will achieve
Components, props, state, `map()` with keys, and loading data with `useEffect`.

## 3. Preflight
```bash
node -v
npm -v
curl "http://localhost:8000/encounters?limit=2"   # should print a JSON array
```
Also open http://localhost:8000/docs.

## 4. Setup
```bash
npm install
cp .env.example .env     # optional
npm run dev              # frontend: http://localhost:5173
```
Backend: FastAPI on http://localhost:8000.

## 5. Checkpoints (stop when each works)
Handouts are in [`classroom/`](classroom/). They are incremental edits to this one project; `src/` holds the final CP8 version.

- [ ] CP1 Vite page opens, no terminal errors
- [ ] CP2 JSX heading and subtitle render
- [ ] CP3 `Header` component, page looks the same
- [ ] CP4 One row via props
- [ ] CP5 Button → state → two sample rows
- [ ] CP6 `PatientTable` + `map()` + keys
- [ ] CP7 Button loads real rows with `fetch`
- [ ] CP8 `useEffect` auto-loads; loading/error/empty work
- [ ] CP9 Add the Days in Hospital column

## 6. Component tree
```text
App                      state: encounters, loading, error
 ├─ Header
 └─ PatientTable         props: encounters (array)
     └─ PatientRow ×N    props: encounter (one item), key = encounter_id
```

## 7. Debugging: find the first broken arrow
`Backend → Network tab → fetch → setEncounters → App state → props → PatientTable → PatientRow → browser`

| Symptom | Likely cause |
|---|---|
| "Failed to fetch" / CORS | Backend off, or origin/port not allowed |
| `map is not a function` | Response isn't an array |
| Key warning | Missing `key={item.encounter_id}` |
| Type-import error | Use `import type` |
| `.env` change ignored | Restart `npm run dev` |

## 8. Build
```bash
npm run build
```

## 9. Self-assessment
- What is a component?
- What are props?
- What is state?
- What happens after `setEncounters(data)`?
- Why is `key` needed for rows?
- Why do we call the API inside `useEffect`?

## 10. Sunday preview
You will build a **different** small application with GET + POST, independently.
