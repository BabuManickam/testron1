# Trainer Notes — Week 4, Day 7

## Pacing
If fewer than two-thirds of learners have the main table working at **02:40**, skip the optional search and use the last 20 minutes for troubleshooting.

## Concept contrast
- Props flow **down** into the child.
- State lives where it is updated (`App`).
- One state update triggers React rendering.

## Most common errors
- Wrong component export/import
- `class` vs `className`
- Forgetting `key`
- `map` on a non-array
- `getElementById` misuse inside React
- CORS
- Vite port mismatch
- API not running
- Missing `import type` for type imports

## React Strict Mode
In development the effect may run, clean up, and run again — an extra Network request is expected, not a bug. Keep the cleanup (`controller.abort()`).

## No new backend
Don't rebuild FastAPI or the database during React teaching. See `backend_notes/GET_CONTRACT_AND_CORS.md`.

## No misleading success
If the backend is unavailable, demonstrate through CP6 with clearly labeled synthetic sample data. Mark CP8 as **unverified** and don't announce completion.

## Teaching rules
- Build one project; show one idea per checkpoint; wait for the STOP result.
- Don't show the finished `App.tsx` before the first JSX demo.
- No React Router, Redux, Axios, Tailwind or TanStack Query.

## Sunday
The independent project is requirements-led and different from Saturday's patient app. Don't give them this app as their task.
