import { useEffect, useState } from 'react';

export function usePaginatedFetch<T>(url: string, pageSize = 10, offsetParam = 'offset') {
  const [data, setData] = useState<T[]>([]);
  const [page, setPage] = useState(1);

  useEffect(() => {
    const offset = (page - 1) * pageSize;
    fetch(`${url}?${offsetParam}=${offset}&limit=${pageSize}`)
      .then((response) => response.json())
      .then((result) => setData(result))
      .catch((error) => console.error('Error fetching data:', error));
  }, [url, page, pageSize, offsetParam]);

  return { data, page, setPage, hasNext: data.length === pageSize };
}
