import Header from './components/Header';
import PatientTable from './components/PatientTable';
import Pagination from './components/Pagination';
import { usePaginatedFetch } from './hooks/usePaginatedFetch';
import type { Encounter } from './types';
import './App.css';

function App() {
  const { data: encounters, page, setPage, hasNext } =
    usePaginatedFetch<Encounter>('http://localhost:8000/encounters');

  return (
    <div className="App">
      <Header />
      <PatientTable encounters={encounters} />
      <Pagination page={page} onPageChange={setPage} hasNext={hasNext} />
    </div>
  );
}

export default App;
