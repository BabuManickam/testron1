interface PaginationProps {
  page: number;
  onPageChange: (page: number) => void;
  hasNext: boolean;
}

function Pagination({ page, onPageChange, hasNext }: PaginationProps) {
  return (
    <div className="pagination">
      <button onClick={() => onPageChange(page - 1)} disabled={page === 1}>
        Previous
      </button>
      <span>Page {page}</span>
      <button onClick={() => onPageChange(page + 1)} disabled={!hasNext}>
        Next
      </button>
    </div>
  );
}

export default Pagination;
